<?php
$username=$_POST["username"];
$email=$_POST["email"];
$password=$_POST["password"];

$connect=mysqli_connect('localhost','root','','assignment');
$SQL="insert into review_users(id,username,email,password) value('','$username','$email','$password')";

if(mysqli_query($connect,$SQL))
{
    header("location:index.php");
}else{
    echo "Registration is failed".mysqli_error($connect);
}
mysqli_close($con);
?>