<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/all.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins&display=swap');
*{
    margin: 0;
    padding: 0;
    font-family: 'Poppins', sans-serif;
}
body
{
    background-color: rgb(243, 243, 243);
}
.flex{
    display: flex;
}
.justify_cnt
{
    justify-content: space-between;
}
.margin_equal
{
    margin: auto 250px; 
}
.container
{
    background-color: #333;
    position: fixed;
    width: 100%;
}
.header
{
    color: white;
    font-family: 'Poppins', sans-serif;
    padding: 10px;
}
.header_inner_left p
{
    font-size: 1.1rem;
    font-weight: 600;
}
.header_inner_right span
{
    padding: 0px 10px;
}
.header i.fa-bars
{
    padding-right: 10px;
}
.header a
{
    padding-right: 10px;
    color: white;
    text-decoration: none;
}



.content
{
    background-color: rgb(255, 255, 255);
}
.movie_review
{
    padding: 10px;
}
.movie_review .movie_inner .movie_img
{
    width: 400px;
    height: 300px;
}
.movie_review .movie_inner .movie_img img
{
    width: 400px;
    height: 300px;
}
.movie_review .movie_inner .movie_review_content
{
    padding: 20px;
}
.movie_review .movie_inner .movie_review_content p
{
    color: black;
    padding-bottom: 15px;
}
.movie_review .movie_inner .movie_review_content p i.fa-star
{
    color: #FDCC0D;
}
.movie_review .movie_inner .movie_review_content p:nth-child(1)
{
    font-size: 30px;
   font-weight: 600;
   text-transform: uppercase;
}
.movie_review .movie_inner .movie_review_content p:nth-child(3)
{
    font-size: 16px;
    text-justify: justify;
}

.movie_review .comment_box
{
    padding: 10px;
}
.movie_review .comment_box p
{
    font-size: 20px;
    padding: 10px 0px;
}
.movie_review .comment_box textarea
{
    width: 96%;
    height: 200px;
    padding: 15px;
    font-size: 16px;
}
.movie_review .comment_box form input[type="submit"]
{
    width: 200px;
    height: 45px;
    border: 2px solid #333;
    border-radius: 3px;
    background-color: white;
    cursor: pointer;
    transition: all .3s;
}
.movie_review .comment_box form input[type="submit"]:hover
{
    background-color: #333;
    color: white;
}
.movie_review .comment_receive_box
{
    padding: 50px;
}
.movie_review .comment_receive_box .comment_receive_inner
{
    border: 1px solid rgba(0, 0, 0, 0.3);
    border-radius: 3px;
    padding: 10px;
    margin-bottom: 10px;
}
.movie_review .comment_receive_box p
{
    color: black;
    background-color: white;
    padding:0px 0 40px 0;
    font-size:14px;
    border:none;
    border-bottom:1px solid black;
}
.movie_review .comment_receive_box h2
{
    color: black;
    padding:10px 0;
    background-color: white;
    font-size:24px;
}
    </style>
</head>
<body onload="local_data()">
    <div class="container">
        <div class="header flex margin_equal justify_cnt">
            <div class="header_inner_left">
            <p>
                <i class="fas fa-bars"></i> Movie <span style="font-family: cursive;"><span style="color: rgb(121, 121, 255);">fli</span>cks</span>
            </p>
            </div>
            <div class="header_inner_right">
            <a href=""><i class="far fa-question-circle"></i> Help</a>
                <span>|</span>
                <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                <span>|</span>
                <a id="userName">
                <?php echo $_SESSION['username']; ?>
                </a>
            </div>
        </div>
    </div>
    <br><br>
    <div class="margin_equal content">
        <div class="movie_review">
            <div class="movie_inner flex">
                <div class="movie_img">
                    <img src="images/img2.jpg" alt="">
                </div>
                <div class="movie_review_content">
                        <p>sanju</p>
                        <p>8.9 <i class="fas fa-star"></i></p>
                        <p>Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, 
                            graphic or web designs. The passage is attributed to an unknown typesetter in the 
                            15th century who is thought to have scrambled parts of Cicero's De Finibus Bonorum et 
                            Malorum for use in a type specimen book.</p>
                </div>
            </div>
            <div class="comment_box">
                <p>comments</p>
                <form action="">
                    <textarea placeholder="Text Here" id="comment"></textarea>
                    <input type="submit" placeholder="Submit" onclick="addcomment()" required>
                </form>
            </div>
            <div class="comment_receive_box">

            </div>
        </div>
    </div>
    <script>
                function local_data(){
            if(localStorage.sanju){
                someArray=JSON.parse(localStorage.sanju);
                for(var i=0; i<someArray.length; i++){
                    var com=someArray[i].comment;
                    var user=someArray[i].name;
                    predata(com,user);
                }
            }
        }


        var someArray=[];
        function addcomment(){
            var com=document.getElementById('comment').value;
            var user=document.getElementById("userName").innerHTML;
            var comment=document.querySelector(".comment_receive_box");
            var newTwo=document.createElement("H2");
            var newOne=document.createElement("P");
            comment.appendChild(newTwo);
            comment.appendChild(newOne);
            newOne.innerHTML=com;
            newTwo.innerHTML=user;
            if(com=="")
            {
                alert("comment box is empty");
                return false;
            }

            //to clear the input field
            document.getElementById('comment').value="";

            var nums={name:newTwo.innerHTML,comment:newOne.innerHTML,};
                  someArray.push(nums);
                  localStorage.sanju=JSON.stringify(someArray);
                //   console.log(nums);

            
        }
        function predata(com,user){
            var comment=document.querySelector(".comment_receive_box");
            var newTwo=document.createElement("H2");
            var newOne=document.createElement("P");
            comment.appendChild(newTwo);
            comment.appendChild(newOne);
            newOne.innerHTML=com;
            newTwo.innerHTML=user;
            // console.log(com);
            // console.log(user);
        }
    </script>
</body>
</html>