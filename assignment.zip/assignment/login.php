<?php
session_start();
if(isset($_POST["username"]) && isset($_POST['password'])){

    $uname=$_POST['username'];
    $pass=$_POST['password'];

    $_SESSION['username']=$uname;

    $connect=mysqli_connect('localhost','root','','assignment');
    $SQL="select *from review_users where username='$uname' and password='$pass'";
    $run=mysqli_query($connect,$SQL);

    $result=mysqli_fetch_array($run);

    $db_uname=$result['username'];
    $db_password=$result['password'];

    if($uname==$db_uname && $pass==$db_password){
        header("location:index.php");
    }else{
        echo "not matched";
        echo "<a href='login.html'>go back</a>";
    }
}

?>