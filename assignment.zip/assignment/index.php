<?php
session_start();
if(isset($_SESSION['username']))
{ 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="index.css">
    <link rel="stylesheet" href="css/all.css">
</head>
<body>
    <div class="container">
        <div class="header flex margin_equal justify_cnt">
            <div class="header_inner_left">
            <p>
                <i class="fas fa-bars"></i> Movie <span style="font-family: cursive;"><span style="color: rgb(121, 121, 255);">fli</span>cks</span>
            </p>
            </div>
            <div class="header_inner_right">
                <a href=""><i class="far fa-question-circle"></i> Help</a>
                <span>|</span>
                <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                <span>|</span>
                <a id="userName">
                <?php echo $_SESSION['username']; ?>
                </a>
            </div>
        </div>
    </div>
    <br>
    <div class="content">
        <div class="movies margin_equal">
            <div class="movie_one flex">
                <div class="movie_img">
                    <a href="bahubali.php"><img src="images/img1.jpg" alt=""></a>
                </div>
                <div class="movie_name">
                    <p>The Bahubali</p>
                    <p>8.9 <i class="fas fa-star"></i></p>
                    <p>Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, 
                        graphic or web designs. The passage is attributed to an unknown typesetter in the 
                        15th century who is thought to have scrambled parts of Cicero's De Finibus Bonorum et 
                        Malorum for use in a type specimen book.</p>
                </div>
            </div>
            <div class="movie_one flex">
                <div class="movie_img">
                    <a href="sanju.php"><img src="images/img2.jpg" alt=""></a>
                </div>
                <div class="movie_name">
                    <p>Sanju</p>
                    <p>8.9 <i class="fas fa-star"></i></p>
                    <p>Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, 
                        graphic or web designs. The passage is attributed to an unknown typesetter in the 
                        15th century who is thought to have scrambled parts of Cicero's De Finibus Bonorum et 
                        Malorum for use in a type specimen book.</p>
                </div>
            </div>
            <div class="movie_one flex">
                <div class="movie_img">
                    <a href="mission_mangal.html"><img src="images/img3.jpg" alt=""></a>
                </div>
                <div class="movie_name">
                    <p>Mission Mangal</p>
                    <p>8.9 <i class="fas fa-star"></i></p>
                    <p>Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, 
                        graphic or web designs. The passage is attributed to an unknown typesetter in the 
                        15th century who is thought to have scrambled parts of Cicero's De Finibus Bonorum et 
                        Malorum for use in a type specimen book.</p>
                </div>
            </div>
            <div class="movie_one flex">
                <div class="movie_img">
                    <a href="bajrangi.html"><img src="images/img4.jpg" alt=""></a>
                </div>
                <div class="movie_name">
                    <p>Bajrangi Bhaijaan</p>
                    <p>8.9 <i class="fas fa-star"></i></p>
                    <p>Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, 
                        graphic or web designs. The passage is attributed to an unknown typesetter in the 
                        15th century who is thought to have scrambled parts of Cicero's De Finibus Bonorum et 
                        Malorum for use in a type specimen book.</p>
                </div>
            </div>
            <div class="movie_one flex">
                <div class="movie_img">
                    <a href="dangal.html"><img src="images/img5.jpg" alt=""></a>
                </div>
                <div class="movie_name">
                    <p>Dangal</p>
                    <p>8.9 <i class="fas fa-star"></i></p>
                    <p>Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, 
                        graphic or web designs. The passage is attributed to an unknown typesetter in the 
                        15th century who is thought to have scrambled parts of Cicero's De Finibus Bonorum et 
                        Malorum for use in a type specimen book.</p>
                </div>
            </div>
            <div class="movie_one flex">
                <div class="movie_img">
                    <a href="super.html"><img src="images/img6.jpg" alt=""></a>
                </div>
                <div class="movie_name">
                    <p>super 30</p>
                    <p>8.9 <i class="fas fa-star"></i></p>
                    <p>Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, 
                        graphic or web designs. The passage is attributed to an unknown typesetter in the 
                        15th century who is thought to have scrambled parts of Cicero's De Finibus Bonorum et 
                        Malorum for use in a type specimen book.</p>
                </div>
            </div>
            <div class="movie_one flex">
                <div class="movie_img">
                    <a href="bhag.html"><img src="images/img7.jpg" alt=""></a>
                </div>
                <div class="movie_name">
                    <p>Bhaag milkha bhaag</p>
                    <p>8.9 <i class="fas fa-star"></i></p>
                    <p>Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, 
                        graphic or web designs. The passage is attributed to an unknown typesetter in the 
                        15th century who is thought to have scrambled parts of Cicero's De Finibus Bonorum et 
                        Malorum for use in a type specimen book.</p>
                </div>
            </div>
            <div class="movie_one flex">
                <div class="movie_img">
                    <a href="saaho.html"><img src="images/img8.jpg" alt=""></a>
                </div>
                <div class="movie_name">
                    <p>saaho</p>
                    <p>8.9 <i class="fas fa-star"></i></p>
                    <p>Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, 
                        graphic or web designs. The passage is attributed to an unknown typesetter in the 
                        15th century who is thought to have scrambled parts of Cicero's De Finibus Bonorum et 
                        Malorum for use in a type specimen book.</p>
                </div>
            </div>
            <div class="movie_one flex">
                <div class="movie_img">
                    <a href="jersey.html"><img src="images/img9.jpg" alt=""></a>
                </div>
                <div class="movie_name">
                    <p>jersey</p>
                    <p>8.9 <i class="fas fa-star"></i></p>
                    <p>Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, 
                        graphic or web designs. The passage is attributed to an unknown typesetter in the 
                        15th century who is thought to have scrambled parts of Cicero's De Finibus Bonorum et 
                        Malorum for use in a type specimen book.</p>
                </div>
            </div>
            <div class="movie_one flex">
                <div class="movie_img">
                    <a href="baby.html"><img src="images/img10.jpg" alt=""></a>
                </div>
                <div class="movie_name">
                    <p>oh! baby</p>
                    <p>8.9 <i class="fas fa-star"></i></p>
                    <p>Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, 
                        graphic or web designs. The passage is attributed to an unknown typesetter in the 
                        15th century who is thought to have scrambled parts of Cicero's De Finibus Bonorum et 
                        Malorum for use in a type specimen book.</p>
                </div>
            </div>
        </div>
    </div>
    <script>
        var user=document.getElementById("userName").innerHTML;
        console.log(user);
    </script>
</body>
</html>
<?php
    
}else{
    echo '<script language="javascript">alert("first must should be login")</script>';
    header('location:login.html');
}

?>